public class Media {
    public static void main(String[] args) {
    System.out.println("Média=");
    System.out.println((7+8+9)/3);

    /*Variabilizar - Declarar variável*/
 
    float media= 0;
    float nota1 = 7;
    float nota2 =4;
    float nota3= 5;
    float divisor=3;
    media = (nota1+nota2+nota3)/divisor;

    System.out.println("A sua média é de = " + media);
        
    }
}
