public class Aula1 { 
    public static void main(String[] args) {
        System.out.println("Meu primeiro código");
        System.out.println("Unidade1");

        System.out.print("Uma parte da");
        System.out.println(" linha separada");

    }


}
    