public class AreaDaSala {
public static void main(String[] args) {
    float frente = 5.5f;
    float lateral = 8.78f;
    float área = frente*lateral;
    System.out.println("A área da sala é de:" + área);
}
}